'use client';

import { useState } from 'react';
import Image from 'next/image';

interface OptionGroup {
  id: string;
  name: string;
  type: 'radio' | 'checkbox';
  required: boolean;
  options: {
    id: string;
    name: string;
    price?: number;
  }[];
}

interface OrderCustomizationProps {
  item: {
    id: number;
    name: string;
    description: string;
    price: number;
    image: string;
  };
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: any, quantity: number, customizations: any) => void;
}

export default function OrderCustomization({ 
  item, 
  isOpen, 
  onClose, 
  onAddToCart 
}: OrderCustomizationProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string | string[]>>({});
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Mock customization options
  const customizationOptions: OptionGroup[] = [
    {
      id: 'cooking-preference',
      name: 'Cooking Preference',
      type: 'radio',
      required: true,
      options: [
        { id: 'rare', name: 'Rare' },
        { id: 'medium-rare', name: 'Medium Rare' },
        { id: 'medium', name: 'Medium' },
        { id: 'medium-well', name: 'Medium Well' },
        { id: 'well-done', name: 'Well Done' },
      ],
    },
    {
      id: 'sides',
      name: 'Choose Your Side',
      type: 'radio',
      required: true,
      options: [
        { id: 'fries', name: 'French Fries' },
        { id: 'salad', name: 'House Salad' },
        { id: 'mashed-potatoes', name: 'Mashed Potatoes' },
        { id: 'roasted-vegetables', name: 'Roasted Vegetables' },
      ],
    },
    {
      id: 'extras',
      name: 'Add Extras',
      type: 'checkbox',
      required: false,
      options: [
        { id: 'cheese', name: 'Extra Cheese', price: 1.50 },
        { id: 'bacon', name: 'Bacon', price: 2.00 },
        { id: 'sauce', name: 'Special Sauce', price: 0.75 },
        { id: 'avocado', name: 'Avocado', price: 2.50 },
      ],
    },
  ];

  if (!isOpen) return null;

  const handleQuantityChange = (change: number) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  const handleOptionChange = (groupId: string, optionId: string) => {
    const group = customizationOptions.find(g => g.id === groupId);
    
    if (!group) return;
    
    if (group.type === 'radio') {
      setSelectedOptions({
        ...selectedOptions,
        [groupId]: optionId
      });
    } else if (group.type === 'checkbox') {
      const currentSelections = selectedOptions[groupId] as string[] || [];
      if (currentSelections.includes(optionId)) {
        setSelectedOptions({
          ...selectedOptions,
          [groupId]: currentSelections.filter(id => id !== optionId)
        });
      } else {
        setSelectedOptions({
          ...selectedOptions,
          [groupId]: [...currentSelections, optionId]
        });
      }
    }
  };

  const handleAddToCart = () => {
    // Format customizations for display
    const customizationDetails: string[] = [];
    
    customizationOptions.forEach(group => {
      if (group.type === 'radio' && selectedOptions[group.id]) {
        const selectedOption = group.options.find(opt => opt.id === selectedOptions[group.id]);
        if (selectedOption) {
          customizationDetails.push(`${group.name}: ${selectedOption.name}`);
        }
      } else if (group.type === 'checkbox' && (selectedOptions[group.id] as string[] || []).length > 0) {
        const selectedIds = selectedOptions[group.id] as string[];
        const selectedNames = group.options
          .filter(opt => selectedIds.includes(opt.id))
          .map(opt => opt.name)
          .join(', ');
        customizationDetails.push(`${group.name}: ${selectedNames}`);
      }
    });
    
    if (specialInstructions) {
      customizationDetails.push(`Special Instructions: ${specialInstructions}`);
    }
    
    onAddToCart(
      item,
      quantity,
      customizationDetails.join('; ')
    );
    
    onClose();
  };

  // Calculate extra costs from options
  const calculateExtraCost = () => {
    let extraCost = 0;
    
    customizationOptions.forEach(group => {
      if (group.type === 'checkbox' && selectedOptions[group.id]) {
        const selectedIds = selectedOptions[group.id] as string[];
        group.options.forEach(option => {
          if (selectedIds.includes(option.id) && option.price) {
            extraCost += option.price;
          }
        });
      }
    });
    
    return extraCost;
  };

  const extraCost = calculateExtraCost();
  const totalPrice = (item.price + extraCost) * quantity;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-90vh overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold">{item.name}</h2>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 focus:outline-none"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            {customizationOptions.map((group) => (
              <div key={group.id} className="mb-6">
                <h3 className="font-semibold text-lg mb-3">
                  {group.name}
                  {group.required && <span className="text-red-500 ml-1">*</span>}
                </h3>
                
                <div className="space-y-2">
                  {group.options.map((option) => (
                    <div key={option.id} className="flex items-center">
                      <input
                        type={group.type === 'radio' ? 'radio' : 'checkbox'}
                        id={`${group.id}-${option.id}`}
                        name={group.id}
                        checked={
                          group.type === 'radio'
                            ? selectedOptions[group.id] === option.id
                            : (selectedOptions[group.id] as string[] || []).includes(option.id)
                        }
                        onChange={() => handleOptionChange(group.id, option.id)}
                        className="mr-3 h-5 w-5 text-primary focus:ring-primary"
                      />
                      <label htmlFor={`${group.id}-${option.id}`} className="flex-grow cursor-pointer">
                        {option.name}
                        {option.price && <span className="text-gray-600 ml-1">+${option.price.toFixed(2)}</span>}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            <div className="mb-6">
              <h3 className="font-semibold text-lg mb-3">Special Instructions</h3>
              <textarea
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="Any special requests or allergies?"
                className="w-full h-20 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              ></textarea>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <div className="flex justify-between items-center mb-4">
              <span className="font-semibold">Total:</span>
              <span className="font-bold text-xl">${totalPrice.toFixed(2)}</span>
            </div>
            
            <button
              onClick={handleAddToCart}
              className="w-full bg-primary text-white py-3 px-4 rounded-md font-medium hover:bg-primary-dark transition-colors"
            >
              Add to Cart
            </button>
          </div>
          
          <div className="flex flex-col md:flex-row md:space-x-6 mb-6">
            <div className="md:w-1/3 relative h-48 mb-4 md:mb-0">
              <Image 
                src={item.image} 
                alt={item.name}
                layout="fill"
                objectFit="cover"
                className="rounded-md"
              />
            </div>
            
            <div className="md:w-2/3">
              <p className="text-gray-700 mb-4">{item.description}</p>
              <div className="flex items-center justify-between">
                <div className="font-semibold text-lg">${item.price.toFixed(2)}</div>
                <div className="flex items-center border rounded-md">
                  <button 
                    onClick={() => handleQuantityChange(-1)}
                    className="px-3 py-1 text-gray-600 hover:text-primary focus:outline-none"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                    </svg>
                  </button>
                  <span className="px-3 py-1">{quantity}</span>
                  <button 
                    onClick={() => handleQuantityChange(1)}
                    className="px-3 py-1 text-gray-600 hover:text-primary focus:outline-none"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
    </div>
  );
}