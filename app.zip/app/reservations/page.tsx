import React from 'react';
import Calendar from '@/components/reservations/Calendar';
import TimeSelection from '@/components/reservations/TimeSelection';
import ReservationForm from '@/components/reservations/ReservationForm';

export default function ReservationPage() {
  return (
    <main className="container mx-auto py-12 px-4 max-w-4xl">
      <h1 className="text-3xl font-bold mb-8 text-center">Make a Reservation</h1>
      
      <div className="bg-white shadow-md rounded-lg p-6 mb-8">
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">1. Select a Date</h2>
          <Calendar />
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">2. Choose a Time</h2>
          <TimeSelection />
        </div>
        
        <div>
          <h2 className="text-xl font-semibold mb-4">3. Complete Your Reservation</h2>
          <ReservationForm />
        </div>
      </div>
    </main>
  );
}