import { Metadata } from 'next';
import Link from 'next/link';
import CategoryNav from '@/components/menu/CategoryNav';
import MenuItem from '@/components/menu/MenuItems';
import FilterSystem from '@/components/menu/FilterSystem';
import OrderCustomization from '@/components/order/OrderCustomization';

export const metadata: Metadata = {
  title: 'Online Ordering | Restaurant Name',
  description: 'Order delicious meals online for delivery or pickup.',
};

// Mock data for menu categories
const categories = [
  { id: 'appetizers', name: 'Appetizers' },
  { id: 'main-courses', name: 'Main Courses' },
  { id: 'sides', name: 'Sides' },
  { id: 'desserts', name: 'Desserts' },
  { id: 'beverages', name: 'Beverages' },
];

// Mock data for menu items
const menuItems = [
  {
    id: 1,
    name: 'Crispy Calamari',
    description: 'Lightly fried calamari served with lemon aioli',
    price: 12.99,
    image: '/images/calamari.jpg',
    category: 'appetizers',
    dietary: ['pescatarian'],
  },
  {
    id: 2,
    name: 'Filet Mignon',
    description: '8oz center-cut filet with garlic butter and seasonal vegetables',
    price: 32.99,
    image: '/images/filet.jpg',
    category: 'main-courses',
    dietary: ['gluten-free'],
  },
  {
    id: 3,
    name: 'Vegetable Pasta',
    description: 'Fresh fettuccine with seasonal vegetables in a light cream sauce',
    price: 18.99,
    image: '/images/veggie-pasta.jpg',
    category: 'main-courses',
    dietary: ['vegetarian'],
  },
  {
    id: 4,
    name: 'Chocolate Lava Cake',
    description: 'Warm chocolate cake with a molten center and vanilla ice cream',
    price: 9.99,
    image: '/images/lava-cake.jpg',
    category: 'desserts',
    dietary: ['vegetarian'],
  },
];

// Mock dietary preferences for filters
const dietaryOptions = [
  { id: 'vegetarian', label: 'Vegetarian' },
  { id: 'vegan', label: 'Vegan' },
  { id: 'gluten-free', label: 'Gluten-Free' },
  { id: 'pescatarian', label: 'Pescatarian' },
];

export default function OrderPage() {
  return (
    <main className="flex flex-col min-h-screen">
      {/* Fixed cart button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Link
          href="/order/cart"
          className="flex items-center space-x-2 bg-primary text-white px-4 py-3 rounded-full shadow-lg hover:bg-primary-dark transition-colors"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
            />
          </svg>
          <span className="font-medium">View Cart (0)</span>
        </Link>
      </div>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">Online Ordering</h1>
        
        <div className="mb-8">
          <FilterSystem options={dietaryOptions} />
        </div>
        
        <div className="lg:flex lg:space-x-8">
          <div className="lg:w-1/4 mb-6 lg:mb-0">
            <div className="sticky top-24">
              <CategoryNav categories={categories} />
            </div>
          </div>
          
          <div className="lg:w-3/4">
            {categories.map((category) => (
              <section key={category.id} id={category.id} className="mb-12">
                <h2 className="text-2xl font-semibold mb-6 pb-2 border-b border-gray-200">
                  {category.name}
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {menuItems
                    .filter((item) => item.category === category.id)
                    .map((item) => (
                      <MenuItem 
                        key={item.id} 
                        item={item} 
                        actionType="add-to-cart"
                      />
                    ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}