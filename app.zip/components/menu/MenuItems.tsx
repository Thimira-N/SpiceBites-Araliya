'use client';

import Image from 'next/image';
import { useState } from 'react';
import { PlusCircle } from 'lucide-react';

// Sample menu data - in a real app this would come from an API or database
const menuData = {
  appetizers: [
    {
      id: 'a1',
      name: 'Fish Cutlets',
      description: 'Spiced fish and potato croquettes with a crispy coating.',
      price: 8.50,
      image: '/api/placeholder/200/200',
      dietary: ['spicy'],
    },
    {
      id: 'a2',
      name: 'Vegetable Roti',
      description: 'Soft flatbread stuffed with spiced vegetables.',
      price: 7.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian'],
    },
    {
      id: 'a3',
      name: 'Isso Wade',
      description: 'Spicy lentil fritters topped with prawns.',
      price: 9.50,
      image: '/api/placeholder/200/200',
      dietary: ['spicy'],
    },
    {
      id: 'a4',
      name: 'Papadum',
      description: 'Crispy lentil wafers served with chutney.',
      price: 5.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegan', 'gluten-free'],
    },
  ],
  mains: [
    {
      id: 'm1',
      name: 'Chicken Kottu Roti',
      description: 'Chopped roti stir-fried with chicken, vegetables, and spices.',
      price: 16.50,
      image: '/api/placeholder/200/200',
      dietary: ['spicy'],
    },
    {
      id: 'm2',
      name: 'Jackfruit Curry',
      description: 'Young jackfruit cooked in aromatic spices and coconut milk.',
      price: 14.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegan', 'gluten-free'],
    },
    {
      id: 'm3',
      name: 'Black Pork Curry',
      description: 'Slow-cooked pork in a rich blend of roasted spices.',
      price: 18.50,
      image: '/api/placeholder/200/200',
      dietary: ['spicy'],
    },
    {
      id: 'm4',
      name: 'String Hopper Biryani',
      description: 'Rice noodle pancakes layered with spiced vegetables or meat.',
      price: 15.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian'],
    },
  ],
  desserts: [
    {
      id: 'd1',
      name: 'Watalappan',
      description: 'Cardamom and jaggery flavored custard topped with cashew nuts.',
      price: 7.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian', 'gluten-free'],
    },
    {
      id: 'd2',
      name: 'Curd and Treacle',
      description: 'Buffalo milk yogurt served with palm honey.',
      price: 6.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian', 'gluten-free'],
    },
    {
      id: 'd3',
      name: 'Kokis',
      description: 'Crispy coconut cookies made with rice flour.',
      price: 5.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian'],
    },
  ],
  beverages: [
    {
      id: 'b1',
      name: 'Ceylon Tea',
      description: 'Traditional Sri Lankan black tea, served hot.',
      price: 4.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegan', 'gluten-free'],
    },
    {
      id: 'b2',
      name: 'Faluda',
      description: 'Sweet milk drink with rose syrup, basil seeds, and jelly.',
      price: 6.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegetarian'],
    },
    {
      id: 'b3',
      name: 'King Coconut Water',
      description: 'Fresh king coconut water served chilled.',
      price: 5.50,
      image: '/api/placeholder/200/200',
      dietary: ['vegan', 'gluten-free'],
    },
  ],
};

export default function MenuItems() {
  const [activeCategory, setActiveCategory] = useState<keyof typeof menuData>('appetizers');
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Function to check if an item matches current filters and search
  const matchesFilters = (item: any) => {
    // If there are active filters, check if the item has all of them
    if (activeFilters.length > 0) {
      return activeFilters.every(filter => item.dietary.includes(filter));
    }
    return true;
  };

  const matchesSearch = (item: any) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(query) ||
      item.description.toLowerCase().includes(query)
    );
  };

  // Get items for the current category that match filters and search
  const filteredItems = menuData[activeCategory]
    .filter(item => matchesFilters(item) && matchesSearch(item));

  return (
    <div>
      {/* Display menu items for the current category */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredItems.map((item) => (
          <div key={item.id} className="flex bg-white shadow-sm rounded-lg overflow-hidden hover:shadow-md transition-shadow">
            <div className="relative h-32 w-32 flex-shrink-0">
              <Image
                src={item.image}
                alt={item.name}
                fill
                className="object-cover"
              />
            </div>
            <div className="flex-1 p-4 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-medium text-gray-900">{item.name}</h3>
                  <span className="text-amber-600 font-medium">${item.price.toFixed(2)}</span>
                </div>
                <p className="mt-1 text-sm text-gray-600">{item.description}</p>
                <div className="mt-2 flex gap-1">
                  {item.dietary.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-600"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <div className="mt-4 flex justify-end">
                <button className="flex items-center text-sm font-medium text-amber-600 hover:text-amber-700">
                  <PlusCircle className="h-4 w-4 mr-1" />
                  Add to Order
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty state when no items match filters */}
      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <p className="text-lg text-gray-500">No items match your current filters.</p>
          <button
            onClick={() => {
              setActiveFilters([]);
              setSearchQuery('');
            }}
            className="mt-2 text-amber-600 hover:text-amber-700 font-medium"
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
}