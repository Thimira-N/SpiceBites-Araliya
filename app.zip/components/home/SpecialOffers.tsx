'use client';

import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const specialOffers = [
  {
    id: 1,
    title: 'Weekday Lunch Special',
    description: 'Enjoy a 20% discount on all lunch menu items Monday through Thursday.',
    imagePath: '/api/placeholder/800/400',
    color: 'bg-amber-100',
  },
  {
    id: 2,
    title: 'Weekend Brunch Buffet',
    description: 'All-you-can-eat authentic Sri Lankan brunch every Saturday and Sunday, 10am-2pm.',
    imagePath: '/api/placeholder/800/400',
    color: 'bg-emerald-100',
  },
  {
    id: 3,
    title: 'Chef\'s Tasting Menu',
    description: 'Six-course tasting menu featuring seasonal specialties for just $45 per person.',
    imagePath: '/api/placeholder/800/400',
    color: 'bg-red-100',
  },
  {
    id: 4,
    title: 'Happy Hour',
    description: 'Half-price cocktails and appetizers from 4-6pm daily at the bar.',
    imagePath: '/api/placeholder/800/400',
    color: 'bg-blue-100',
  },
];

export default function SpecialOffers() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Autoplay functionality
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === specialOffers.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);
    
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  // Pause autoplay when user interacts
  const pauseAutoplay = () => {
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToPrevious = () => {
    pauseAutoplay();
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? specialOffers.length - 1 : prevIndex - 1
    );
  };

  const goToNext = () => {
    pauseAutoplay();
    setCurrentIndex((prevIndex) => 
      prevIndex === specialOffers.length - 1 ? 0 : prevIndex + 1
    );
  };

  const goToSlide = (index: number) => {
    pauseAutoplay();
    setCurrentIndex(index);
  };

  // Update the slider position when currentIndex changes
  useEffect(() => {
    if (sliderRef.current) {
      sliderRef.current.scrollTo({
        left: sliderRef.current.clientWidth * currentIndex,
        behavior: 'smooth',
      });
    }
  }, [currentIndex]);

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-gray-900 mb-2">Special Offers</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our exclusive promotions and seasonal specialties
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Slider container */}
          <div 
            ref={sliderRef}
            className="overflow-hidden"
          >
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ width: `${specialOffers.length * 100}%` }}
            >
              {specialOffers.map((offer) => (
                <div 
                  key={offer.id} 
                  className="relative w-full px-4"
                  style={{ width: `${100 / specialOffers.length}%` }}
                >
                  <div className={`rounded-lg overflow-hidden shadow-md ${offer.color} p-6 h-full`}>
                    <div className="flex flex-col md:flex-row gap-6 items-center">
                      <div className="md:w-1/2 relative h-48 w-full rounded-md overflow-hidden">
                        <div 
                          className="absolute inset-0 bg-cover bg-center"
                          style={{ backgroundImage: `url(${offer.imagePath})` }}
                        ></div>
                      </div>
                      <div className="md:w-1/2">
                        <h3 className="text-xl font-semibold text-gray-900 mb-3">{offer.title}</h3>
                        <p className="text-gray-700">{offer.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation buttons */}
          <button 
            onClick={goToPrevious}
            className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/2 bg-white rounded-full p-2 shadow-md text-gray-700 hover:text-amber-600 focus:outline-none z-10"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button 
            onClick={goToNext}
            className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 bg-white rounded-full p-2 shadow-md text-gray-700 hover:text-amber-600 focus:outline-none z-10"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            {specialOffers.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`h-2 w-2 rounded-full focus:outline-none ${
                  index === currentIndex ? 'bg-amber-600 w-4' : 'bg-gray-300'
                } transition-all duration-300`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}