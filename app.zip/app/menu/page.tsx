import { Metadata } from 'next';
import CategoryNav from '@/components/menu/CategoryNav';
import MenuItems from '@/components/menu/MenuItems';
import FilterSystem from '@/components/menu/FilterSystem';

export const metadata: Metadata = {
  title: 'Menu | Sri Lankan Flavors',
  description: 'Explore our authentic Sri Lankan dishes - from appetizers to desserts.',
};

export default function MenuPage() {
  return (
    <main className="min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-semibold text-gray-900 mb-2">Our Menu</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover the rich and vibrant flavors of authentic Sri Lankan cuisine
          </p>
        </div>
        
        <div className="flex flex-col space-y-6">
          <div className="sticky top-16 bg-white z-20 pb-4 pt-2">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <CategoryNav />
              <FilterSystem />
            </div>
          </div>
          
          <MenuItems />
        </div>
      </div>
    </main>
  );
}