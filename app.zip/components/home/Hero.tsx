import Link from 'next/link';

export default function Hero() {
  return (
    <div className="relative h-screen w-full">
      {/* Background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center z-0" 
        style={{ 
          backgroundImage: "url('/api/placeholder/1920/1080')",
          /* This would be replaced with your actual hero image */
        }}
      >
        {/* Dark overlay for better text visibility */}
        <div className="absolute inset-0 bg-black opacity-50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
          Sri Lankan Flavors
        </h1>
        <p className="text-xl md:text-2xl text-white mb-8 max-w-2xl">
          Experience the authentic taste of Sri Lanka in a modern setting
        </p>
        <Link 
          href="/reservations" 
          className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 px-8 rounded-md transition-colors duration-300 transform hover:scale-105"
        >
          Reserve a Table
        </Link>
      </div>
    </div>
  );
}