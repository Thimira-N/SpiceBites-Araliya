import Image from 'next/image';

// Team members data
const teamMembers = [
  {
    id: 1,
    name: 'Chef Maria Rodriguez',
    role: 'Executive Chef',
    bio: 'With over 15 years of culinary experience across Europe and America, Maria brings creativity and precision to every dish she creates.',
    image: '/images/chef-maria.jpg',
  },
  {
    id: 2,
    name: 'John Anderson',
    role: 'Sous Chef',
    bio: 'John\'s passion for local ingredients and sustainable cooking practices has been instrumental in developing our farm-to-table program.',
    image: '/images/chef-john.jpg',
  },
  {
    id: 3,
    name: 'Sarah Chen',
    role: 'Pastry Chef',
    bio: 'Sarah\'s innovative approach to desserts combines classic techniques with unexpected flavors, creating memorable final courses.',
    image: '/images/chef-sarah.jpg',
  },
  {
    id: 4,
    name: 'Michael Patel',
    role: 'Restaurant Manager',
    bio: 'Michael ensures that every guest experience is flawless, from reservation to the final farewell, with his attention to detail and warm hospitality.',
    image: '/images/manager-michael.jpg',
  },
  {
    id: 5,
    name: 'Emma Wilson',
    role: 'Sommelier',
    bio: 'Emma\'s expert knowledge of wines and beverages helps create perfect pairings that elevate our culinary offerings.',
    image: '/images/sommelier-emma.jpg',
  },
  {
    id: 6,
    name: 'David Kim',
    role: 'Bar Manager',
    bio: 'David crafts innovative cocktails that reflect the seasons and complement our menu, using house-made ingredients and artisanal spirits.',
    image: '/images/bartender-david.jpg',
  },
];

export default function TeamSection() {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {teamMembers.map((member) => (
          <div key={member.id} className="bg-white rounded-lg overflow-hidden shadow-sm transition-transform hover:shadow-md hover:-translate-y-1">
            <div className="relative h-64 w-full">
              <Image
                src={member.image}
                alt={member.name}
                layout="fill"
                objectFit="cover"
              />
            </div>
            
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
              <p className="text-primary font-medium mb-3">{member.role}</p>
              <p className="text-gray-600">{member.bio}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}