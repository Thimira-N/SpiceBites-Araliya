'use client';

import React, { useState } from 'react';

export default function ReservationForm() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    specialRequests: '',
    isSubmitted: false
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState({
      ...formState,
      [name]: value
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would submit the form data to your backend here
    // For this example, we'll just show the confirmation view
    setFormState({
      ...formState,
      isSubmitted: true
    });
  };
  
  const handleAddToCalendar = () => {
    // In a real app, this would generate a calendar file or link
    alert('This would add the reservation to your calendar in a real application.');
  };
  
  const handleModify = () => {
    setFormState({
      ...formState,
      isSubmitted: false
    });
  };
  
  if (formState.isSubmitted) {
    return (
      <div className="bg-white p-6 rounded-lg text-center">
        <div className="mb-4">
          <svg className="mx-auto h-12 w-12 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Reservation Confirmed!</h3>
        <p className="text-gray-600 mb-6">
          Thank you, {formState.name}! Your reservation has been confirmed. We've sent a confirmation email to {formState.email}.
        </p>
        <div className="flex flex-col sm:flex-row justify-center space-y-2 sm:space-y-0 sm:space-x-2">
          <button 
            onClick={handleAddToCalendar}
            className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Add to Calendar
          </button>
          <button 
            onClick={handleModify}
            className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Modify Reservation
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-4">
        <div className="relative">
          <input
            type="text"
            id="name"
            name="name"
            value={formState.name}
            onChange={handleInputChange}
            required
            className="peer h-12 w-full border-b border-gray-300 text-gray-900 placeholder-transparent focus:outline-none focus:border-indigo-600"
            placeholder="Full Name"
          />
          <label 
            htmlFor="name" 
            className="absolute left-0 -top-3.5 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-gray-600 peer-focus:text-sm"
          >
            Full Name
          </label>
        </div>
        
        <div className="relative">
          <input
            type="email"
            id="email"
            name="email"
            value={formState.email}
            onChange={handleInputChange}
            required
            className="peer h-12 w-full border-b border-gray-300 text-gray-900 placeholder-transparent focus:outline-none focus:border-indigo-600"
            placeholder="Email"
          />
          <label 
            htmlFor="email" 
            className="absolute left-0 -top-3.5 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-gray-600 peer-focus:text-sm"
          >
            Email
          </label>
        </div>
        
        <div className="relative">
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formState.phone}
            onChange={handleInputChange}
            required
            className="peer h-12 w-full border-b border-gray-300 text-gray-900 placeholder-transparent focus:outline-none focus:border-indigo-600"
            placeholder="Phone Number"
          />
          <label 
            htmlFor="phone" 
            className="absolute left-0 -top-3.5 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-gray-600 peer-focus:text-sm"
          >
            Phone Number
          </label>
        </div>
        
        <div className="relative">
          <textarea
            id="specialRequests"
            name="specialRequests"
            rows={4}
            value={formState.specialRequests}
            onChange={handleInputChange}
            className="peer w-full border border-gray-300 text-gray-900 placeholder-transparent focus:outline-none focus:border-indigo-600 p-2 rounded-md mt-6"
            placeholder="Special Requests (optional)"
          />
          <label 
            htmlFor="specialRequests" 
            className="absolute left-0 -top-3.5 text-gray-600 text-sm"
          >
            Special Requests (optional)
          </label>
        </div>
      </div>
      
      <div className="mt-6">
        <button
          type="submit"
          className="w-full inline-flex justify-center py-3 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          Confirm Reservation
        </button>
      </div>
      
      <p className="mt-4 text-xs text-gray-500 text-center">
        By confirming, you agree to our reservation policy. A credit card may be required to hold your reservation.
      </p>
    </form>
  );
}