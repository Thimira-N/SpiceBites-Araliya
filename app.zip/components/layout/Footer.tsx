import Link from 'next/link';
import { MapPin, Clock, Phone, Mail, Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Contact Information */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 uppercase mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-amber-600 mr-2 mt-0.5" />
                <span className="text-sm text-gray-600">
                  123 Spice Lane, Colombo 05, Sri Lanka
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-amber-600 mr-2" />
                <span className="text-sm text-gray-600">+94 11 234 5678</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-amber-600 mr-2" />
                <span className="text-sm text-gray-600">info@srilankanflavors.com</span>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 uppercase mb-4">Opening Hours</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Clock className="h-5 w-5 text-amber-600 mr-2 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Monday - Friday</p>
                  <p className="text-sm text-gray-600">11:00 AM - 10:00 PM</p>
                </div>
              </li>
              <li className="flex items-start">
                <Clock className="h-5 w-5 text-amber-600 mr-2 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Saturday - Sunday</p>
                  <p className="text-sm text-gray-600">10:00 AM - 11:00 PM</p>
                </div>
              </li>
            </ul>
          </div>

          {/* Social Media Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 uppercase mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <Link href="https://instagram.com" className="text-gray-600 hover:text-amber-600">
                <span className="sr-only">Instagram</span>
                <Instagram className="h-6 w-6" />
              </Link>
              <Link href="https://facebook.com" className="text-gray-600 hover:text-amber-600">
                <span className="sr-only">Facebook</span>
                <Facebook className="h-6 w-6" />
              </Link>
              <Link href="https://twitter.com" className="text-gray-600 hover:text-amber-600">
                <span className="sr-only">Twitter</span>
                <Twitter className="h-6 w-6" />
              </Link>
            </div>
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Newsletter</h4>
              <form className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-3 py-2 border border-gray-300 rounded-l-md w-full focus:outline-none focus:ring-1 focus:ring-amber-600 text-sm"
                />
                <button
                  type="submit"
                  className="bg-amber-600 text-white px-4 py-2 rounded-r-md text-sm font-medium hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-gray-200">
          <p className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Sri Lankan Flavors. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}