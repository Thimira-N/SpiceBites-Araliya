'use client';

import React, { useState } from 'react';

export default function TimeSelection() {
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedPartySize, setSelectedPartySize] = useState(2);
  
  // Available time slots
  const timeSlots = [
    '11:00 AM', '11:30 AM', 
    '12:00 PM', '12:30 PM', 
    '1:00 PM', '1:30 PM',
    '5:00 PM', '5:30 PM', 
    '6:00 PM', '6:30 PM', 
    '7:00 PM', '7:30 PM',
    '8:00 PM', '8:30 PM',
    '9:00 PM'
  ];
  
  // Handle time selection
  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
  };
  
  // Handle party size change
  const increasePartySize = () => {
    if (selectedPartySize < 20) {
      setSelectedPartySize(selectedPartySize + 1);
    }
  };
  
  const decreasePartySize = () => {
    if (selectedPartySize > 1) {
      setSelectedPartySize(selectedPartySize - 1);
    }
  };
  
  return (
    <div>
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Select Party Size</h3>
        <div className="flex items-center">
          <button 
            onClick={decreasePartySize}
            disabled={selectedPartySize === 1}
            className={`
              h-10 w-10 rounded-l-md flex items-center justify-center bg-gray-100
              ${selectedPartySize === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-200'}
            `}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
            </svg>
          </button>
          <div className="h-10 w-12 flex items-center justify-center border-t border-b">
            {selectedPartySize}
          </div>
          <button 
            onClick={increasePartySize}
            disabled={selectedPartySize === 20}
            className={`
              h-10 w-10 rounded-r-md flex items-center justify-center bg-gray-100
              ${selectedPartySize === 20 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-200'}
            `}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </button>
          <span className="ml-3 text-sm text-gray-500">People</span>
        </div>
      </div>
      
      <h3 className="text-sm font-medium text-gray-700 mb-2">Available Time Slots</h3>
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-2">
        {timeSlots.map((time) => (
          <button
            key={time}
            onClick={() => handleTimeSelect(time)}
            className={`
              py-2 px-4 rounded-full text-sm font-medium transition-colors
              ${selectedTime === time 
                ? 'bg-indigo-600 text-white' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}
            `}
          >
            {time}
          </button>
        ))}
      </div>
      
      {selectedTime && (
        <div className="mt-4 p-4 bg-gray-50 rounded-md">
          <p className="text-sm text-gray-600">
            Table for <span className="font-medium">{selectedPartySize}</span> at{' '}
            <span className="font-medium">{selectedTime}</span>
          </p>
        </div>
      )}
    </div>
  );
}