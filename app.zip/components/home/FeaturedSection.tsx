import Image from 'next/image';

// Featured dishes data
const featuredDishes = [
  {
    id: 1,
    name: 'Kottu Roti',
    description: 'Chopped roti stir-fried with spices, vegetables, and your choice of protein.',
    imagePath: '/api/placeholder/400/300',
  },
  {
    id: 2,
    name: 'Black Pork Curry',
    description: 'Slow-cooked pork in a rich blend of roasted spices and aromatic herbs.',
    imagePath: '/api/placeholder/400/300',
  },
  {
    id: 3,
    name: 'Pol Sambol',
    description: 'Freshly grated coconut mixed with chili, lime, and spices.',
    imagePath: '/api/placeholder/400/300',
  },
];

export default function FeaturedSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-semibold text-gray-900 mb-2">Our Signature Dishes</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover the authentic flavors of Sri Lanka through our carefully crafted signature dishes
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredDishes.map((dish) => (
            <div 
              key={dish.id} 
              className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 transform hover:scale-[1.02] transition-transform duration-300"
            >
              <div className="relative h-56 w-full">
                <Image
                  src={dish.imagePath}
                  alt={dish.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{dish.name}</h3>
                <p className="text-gray-600">{dish.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}