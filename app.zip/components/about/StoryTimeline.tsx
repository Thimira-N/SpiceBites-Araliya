import Image from 'next/image';

// Timeline events data
const timelineEvents = [
  {
    id: 1,
    year: '2010',
    title: 'Our Beginning',
    description: 'What started as a small family bistro with just 10 tables quickly became known for its exceptional cuisine and warm atmosphere.',
    image: '/images/beginning.jpg',
    position: 'left',
  },
  {
    id: 2,
    year: '2013',
    title: 'Expanding Our Vision',
    description: 'After three successful years, we expanded our space to accommodate more guests and introduced our signature tasting menu.',
    image: '/images/expansion.jpg',
    position: 'right',
  },
  {
    id: 3,
    year: '2015',
    title: 'Award-Winning Recognition',
    description: 'Our dedication to culinary excellence was recognized with our first prestigious restaurant award, putting us on the map.',
    image: '/images/award.jpg',
    position: 'left',
  },
  {
    id: 4,
    year: '2018',
    title: 'Farm-to-Table Initiative',
    description: 'We launched our farm-to-table program, partnering with local farmers to bring the freshest seasonal ingredients to our menu.',
    image: '/images/farm.jpg',
    position: 'right',
  },
  {
    id: 5,
    year: '2020',
    title: 'Adapting & Innovating',
    description: 'During challenging times, we pivoted to offer gourmet meal kits and virtual cooking classes, maintaining our connection with the community.',
    image: '/images/innovation.jpg',
    position: 'left',
  },
  {
    id: 6,
    year: '2022',
    title: 'Our New Home',
    description: 'We moved to our current location, a beautifully renovated historic building that provides the perfect backdrop for our culinary creations.',
    image: '/images/new-location.jpg',
    position: 'right',
  },
  {
    id: 7,
    year: 'Today',
    title: 'Looking to the Future',
    description: 'As we continue to grow and evolve, our commitment to quality, creativity, and hospitality remains at the heart of everything we do.',
    image: '/images/today.jpg',
    position: 'left',
  },
];

export default function StoryTimeline() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="relative">
        {/* Center line */}
        <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-px bg-gray-300"></div>
        
        <div className="space-y-12 md:space-y-0">
          {timelineEvents.map((event) => (
            <div key={event.id} className="relative md:flex items-center mb-16">
              {/* Timeline dot */}
              <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-primary border-4 border-white z-10"></div>
              
              {/* Content wrapper */}
              <div className={`md:w-1/2 ${
                event.position === 'left' 
                  ? 'md:pr-12' 
                  : 'md:pl-12 md:ml-auto'
              }`}>
                {/* Mobile year display */}
                <div className="md:hidden bg-primary text-white text-lg font-bold px-4 py-1 rounded-full inline-block mb-3">
                  {event.year}
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  {/* Desktop year display */}
                  <div className="hidden md:block text-primary text-xl font-bold mb-2">
                    {event.year}
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-3">{event.title}</h3>
                  <p className="text-gray-600 mb-4">{event.description}</p>
                  
                  <div className="relative h-48 w-full rounded-lg overflow-hidden">
                    <Image
                      src={event.image}
                      alt={event.title}
                      layout="fill"
                      objectFit="cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}