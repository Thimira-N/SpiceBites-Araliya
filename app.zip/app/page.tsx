import { Metadata } from 'next';
import Hero from '@/components/home/Hero';
import FeaturedSection from '@/components/home/FeaturedSection';
import SpecialOffers from '@/components/home/SpecialOffers';

export const metadata: Metadata = {
  title: 'Sri Lankan Flavors - Authentic Sri Lankan Cuisine',
  description: 'Experience the authentic taste of Sri Lanka in a modern setting.',
};

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Hero />
      <FeaturedSection />
      <SpecialOffers />
    </main>
  );
};