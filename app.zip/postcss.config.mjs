// const config = {
//   plugins: ["@tailwindcss/postcss"],
// };

// export default config;




/** @type {import('tailwindcss').Config} */
export default {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}