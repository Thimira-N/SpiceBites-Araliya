import { Metadata } from 'next';
import StoryTimeline from '@/components/about/StoryTimeline';
import TeamSection from '@/components/about/TeamSection';

export const metadata: Metadata = {
  title: 'Our Story | Restaurant Name',
  description: 'Learn about our journey, our team, and the values that make our restaurant special.',
};

// Mock data for values section
const values = [
  {
    id: 'quality',
    title: 'Quality Ingredients',
    description: 'We source only the finest, freshest ingredients from local farms and trusted suppliers.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-primary mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    id: 'craft',
    title: 'Culinary Craftsmanship',
    description: 'Our passionate chefs blend tradition with innovation to create memorable dining experiences.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-primary mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
      </svg>
    ),
  },
  {
    id: 'community',
    title: 'Community Connection',
    description: 'We believe in building relationships with our guests and supporting our local community.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-primary mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
      </svg>
    ),
  },
];

// Mock timeline data is handled by the StoryTimeline component
// Mock team data is handled by the TeamSection component

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-80 md:h-96 bg-gray-900 text-white flex items-center">
        <div className="absolute inset-0 bg-black opacity-60 z-0"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center z-0" 
          style={{ backgroundImage: "url('/images/restaurant-interior.jpg')" }}
        ></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Story</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto">
            A passion for exceptional food and memorable experiences
          </p>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-8">Welcome to Our Restaurant</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            Founded in 2010, our restaurant has been serving exceptional cuisine in a warm, inviting 
            atmosphere for over a decade. What began as a small family bistro has grown into a 
            beloved culinary destination, while still maintaining the personal touch and attention 
            to detail that made us special from day one.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            Our philosophy is simple: combine the finest ingredients with passionate craftsmanship 
            and genuine hospitality to create memorable dining experiences that bring people together.
          </p>
        </div>
      </section>

      {/* Story Timeline Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Our Journey</h2>
          <StoryTimeline />
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Meet Our Team</h2>
          <TeamSection />
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {values.map((value) => (
              <div key={value.id} className="bg-white p-8 rounded-lg shadow-sm text-center">
                {value.icon}
                <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Come Experience Our Story</h2>
          <p className="text-xl max-w-3xl mx-auto mb-8">
            Join us for a meal and become part of our continuing journey. We look forward to serving you.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a 
              href="/reservations" 
              className="bg-white text-primary px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
            >
              Make a Reservation
            </a>
            <a 
              href="/menu" 
              className="border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-primary transition-colors"
            >
              View Our Menu
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}